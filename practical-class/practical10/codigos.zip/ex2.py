def soma1(L, i = 0):
    #Implemente a função usando a variável 'i' para controlar 
    # o número de vezes que a função será chamada recursivamente
    return 0

def soma2(L):
    #Implemente a função usando fatiamento
    return 0

def main():
    print("Soma1: ", soma1(list(range(1, 100))))
    print("Soma2: ", soma2(list(range(1, 100))))

main()